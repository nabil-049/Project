<?php
	include "header.php";
	include "dbconnect.php";

	$sql = "SELECT * FROM customer_order";
	$result = $conn->query($sql);
?>

<h1 align="center">Customer & Order List</h1>
<table>
	<tr>
		<th>SL</th>
		<th>Customer Name</th>
		<th>Product Name</th>
		<th>Phone</th>
		<th>Email</th>
		<th>Address</th>
		<th>Quantity</th>
	</tr>
	<?php
		while($row=$result->fetch_assoc()){
			
			echo "<tr>"; 
			echo "<td>".$row["id"] ."</td>";	
			echo "<td>".$row["customer_name"] ."</td>";	
			echo "<td>". $row["product_name"]."</td>";	
			echo "<td>". $row["phone"]."</td>";	
			echo "<td>". $row["email"]."</td>";	
			echo "<td>". $row["address"]."</td>";	
			echo "<td>". $row["quantity"]."</td>";	
			echo "</tr>"; 
		}
	
	?>
			
</table>
		
<?php
	include "footer.php";
?>		


