<div class="footer">
			Developed and maintained by _Nabil_. &copy; 2024
		</div>
	</body>
</html>