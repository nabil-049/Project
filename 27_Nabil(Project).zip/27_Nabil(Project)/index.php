<?php
	include "header.php";
	//include "dbconnect.php";
	
	//$sql="SELECT * FROM facility";
	//$result=$conn->query($sql);
	
?>
<div class="notes">
<marquee> <b> <i style="color:#B53471"> ElectroMart</i></b> – Your Ultimate Destination for Electronics and Gadgets!</marquee>
</div>
	<div class="announce">
		 
		<p>Welcome to ElectroMart, your ultimate destination for the latest and greatest in electronics and gadgets! 
		We pride ourselves on being a one-stop-shop for all your tech needs, offering an extensive range of high-quality products that cater to every tech enthusiast's desires.</p>
		<h2><u>Our Mission:</u></h2>
		<p> At ElectroMart, our mission is simple: to provide our customers with the best selection of cutting-edge electronics and gadgets, coupled with exceptional customer service and unbeatable prices. We strive to make technology accessible and enjoyable for everyone, ensuring that our customers can find the perfect devices to enhance their everyday lives. </p>
		<h2><u> Quality and Reliability:</u> </h2>
		<p> We understand that when it comes to electronics, quality is paramount. That's why we source our products from top brands and reputable manufacturers, ensuring that every item in our store meets the highest standards of performance and durability.</p>
	
	    <h2><u> Exceptional Customer Service:</u>  </h2>
	     <p> Our customers are at the heart of everything we do. Our knowledgeable and friendly staff are always ready to assist you with any questions or concerns, providing expert advice to help you make informed decisions. We believe in building lasting relationships with our customers, and your satisfaction is our top priority.</p>
	</div>
		
<?php
	include "footer.php";
?>

