<?php
	include "header.php";
	include "dbconnect.php";
	
	$sql="SELECT * FROM product";
	$result=$conn->query($sql);
	
?>		
	<div class="apply">
		<h2 align="center">Order Online</h2>
	    <form action="application_action.php" method="POST">
		
			<label>Customer Name</label>
			<input type="text" name="name" placeholder=" Enter Your name....">
			<label>Phone</label>
			<input type="text" name="phone" placeholder="Enter Your Phone...">
			<label>Email</label>
			<input type="email" name="email" placeholder="Enter Your Email...">
			<label>Address</label>
			<input type="text" name="address" placeholder="Enter Delivery Address...">
			<label>Choose Product</label>
			<select name="product">
			<?php
				while($row=$result->fetch_assoc()){
		echo '<option value="'.$row["name"] .'">'.$row["name"] .'</option>';
				}
			?>
			</select>
			<label>Quantity</label>
			<input type="text" name="quantity" placeholder="Enter Quantity...">
			<input type="submit" value="Submit">
		  </form>
	</div>
	
<?php
	include "footer.php";
?>


