<?php 
include "header.php";
include "dbconnect.php";

$sql = "SELECT * FROM product";
$result = $conn->query($sql);


$conn->close();
?>


<html>
<head>
<title>Product</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1 align="center">Product</h1>
<table>
<tr>
<th> ID </th>
<th>Name</th>
<th>Description</th>
<th>Price</th>
<th> Edit</th>
<th> Delete </th>
</tr>
			
<?php 
if ($result->num_rows > 0) 
{
while($row = $result->fetch_assoc())
{ 
$id=$row["id"];
echo "<tr>";
echo "<td>". $row["id"]."</td>";
echo "<td>". $row["name"]."</td>";
echo "<td>". $row["description"]."</td>";

echo "<td>". $row["price"]."</td>";
echo "<td>"."<a href='update.php?editid=$id'>Edit</a>"."</td>";
echo "<td>"."<a href='delete.php?delid=$id'>Delete</a>"."</td>";
echo "</tr>";
}
}
else echo "No results";
		
?>
			
</table>
		
<?php
	include "footer.php";
?>

