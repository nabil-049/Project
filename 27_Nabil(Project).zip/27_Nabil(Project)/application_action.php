<?php
	include "dbconnect.php";
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$name=$_POST["name"];
		$pname=$_POST["product"];
		$phon=$_POST["phone"];
		$email=$_POST["email"];
		$address=$_POST["address"];
		$quantity=$_POST["quantity"];
		
		$sql="INSERT INTO customer_order(id, customer_name, product_name, phone, email,address, quantity)
		values(NULL, '$name', '$pname', '$phon', '$email','$address','$quantity')";
		$result=$conn->query($sql);
		if($result)
		{
			//echo "Success";
			header("Location:applicant_list.php");
		}
		else
		{
			echo "Application failed";
		}
	}
	
?>