<?php
$id = $_POST['id'];
$name = $_POST['name'];
$description = $_POST['description'];
$price = $_POST['price'];


$server_name = "localhost";
$user_name = "root";
$password = "";
$database_name = "project";

$conn = new mysqli($server_name, $user_name, $password, $database_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE product SET name='$name', description='$description', price='$price'  WHERE id=$id";
$result=$conn->query($sql);

if ($result) {
    header("Location:products.php");
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();


exit();
?>
