
<html lang="en">
	<head>
	<title> Home</title>
	<link rel="stylesheet" href="style.css">

	</head>
	<body>

		<div class="header">
		   <h1><img src="project.jpg"  class="logo"> ElectroMart-Electronics and Gadgets</h1>
		</div>

		<div class="topnav">
		  <a href="index.php">About</a>
		  <a href="products.php">Available Products</a>
		  <a href="application.php">Order Online</a>
		</div>
		
		
		
		